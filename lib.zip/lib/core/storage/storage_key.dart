class LocalStorageKeys {
  static const String token = "token";
  static const String refreshToken = "refreshToken";
  static const String isLogIn = "isLogIn";
  static const String userId = "userId";
  static const String myImage = "myImage";
  static const String myName = "myName";
  static const String myEmail = "myEmail";
  static const String myRole = "myRole";
  static const String profileImage = "profileImage";
  static const String deviceId = "deviceId";
  static const String offlineFilePrefix = "offline_file_";
  String _getDownloadKey(String programId) => "downloaded_path_$programId";
}
